# BMW

精準網格搭配深淺交錯的產品敘事。

這套設計規格與所有指令均可免費使用，無須登入。

- [完整設計規格](DESIGN.md)
- [重新撰寫的 AI 指令](PROMPTS.md)
- [淺色元件預覽](preview.html)
- [深色元件預覽](preview-dark.html)
- [回到總目錄](../../README.md)

設計分析源自 VoltAgent 的 MIT 開源資料；AI 指令與預覽由本專案重新製作。預覽是 token 元件示意，不是品牌官方網站截圖。
